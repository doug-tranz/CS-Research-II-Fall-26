# CSR2 files from the 10/14 session

| Folder | What it is |
|---|---|
| `main_update/` | The merged input schema and spec (draft 0.5) for main, plus a git patch. Apply with `git am main_update/0001-*.patch` from a clone of main, then push. Not pushed yet. |
| `synthetic_transcripts/` | 24 fictional students' transcripts (JSON and CSV), the generator, and a README. Valid against the 0.5 schema. |
| `tools/` | The scripts used to build and check the above. `check_merged.py` and `verify_transcripts.py` use a small stand-in validator because `jsonschema` could not be installed; use the repo's own `validate_input()` for the real check. |
| `superseded_v1.0_schema/` | The earlier standalone v1.0 schema and generated spec, built from Ben's branch only. Replaced by `main_update/`; kept for reference. |
