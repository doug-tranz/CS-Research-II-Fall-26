"""Checks the merged schema (stand-in validator; jsonschema cannot be installed here).

usage: check_merged.py <schema.json> <spec.md> <ben_cases.json> <synthetic_transcripts.json>
Validates: every complete JSON example in the spec, Ben's six cases (with registered_crns
added), the synthetic students, then a battery of inputs that must be rejected.
"""
import copy
import json
import re
import sys

schema = json.load(open(sys.argv[1], encoding="utf-8"))
spec = open(sys.argv[2], encoding="utf-8").read()
ben = json.load(open(sys.argv[3], encoding="utf-8"))
synth = json.load(open(sys.argv[4], encoding="utf-8"))


def resolve(ref):
    node = schema
    for part in ref.lstrip("#/").split("/"):
        node = node[part]
    return node


def is_type(v, t):
    return {"object": isinstance(v, dict), "array": isinstance(v, list), "string": isinstance(v, str),
            "boolean": isinstance(v, bool), "integer": isinstance(v, int) and not isinstance(v, bool),
            "number": isinstance(v, (int, float)) and not isinstance(v, bool)}[t]


def validate(v, s, path="<input>"):
    errs = []
    if "$ref" in s:
        errs += validate(v, resolve(s["$ref"]), path)
    for sub in s.get("allOf", []):
        errs += validate(v, sub, path)
    if "if" in s and not validate(v, s["if"], path):
        if "then" in s:
            errs += validate(v, s["then"], path)
    if "oneOf" in s:
        hits = sum(1 for sub in s["oneOf"] if not validate(v, sub, path))
        if hits != 1:
            errs.append(f"{path}: matches {hits} of oneOf")
    if "enum" in s and v not in s["enum"]:
        errs.append(f"{path}: {v!r} not in enum")
    if "const" in s and v != s["const"]:
        errs.append(f"{path}: {v!r} is not {s['const']!r}")
    if "type" in s and not is_type(v, s["type"]):
        return errs + [f"{path}: expected {s['type']}"]
    if isinstance(v, str):
        if "pattern" in s and not re.search(s["pattern"], v):
            errs.append(f"{path}: {v!r} fails pattern {s['pattern']}")
        if len(v) < s.get("minLength", 0):
            errs.append(f"{path}: too short")
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if "minimum" in s and v < s["minimum"]:
            errs.append(f"{path}: below minimum")
        if "maximum" in s and v > s["maximum"]:
            errs.append(f"{path}: above maximum")
        if "exclusiveMinimum" in s and v <= s["exclusiveMinimum"]:
            errs.append(f"{path}: not above {s['exclusiveMinimum']}")
    if isinstance(v, list):
        if len(v) < s.get("minItems", 0):
            errs.append(f"{path}: too few items")
        if s.get("uniqueItems") and len({json.dumps(x, sort_keys=True) for x in v}) != len(v):
            errs.append(f"{path}: items not unique")
        if "items" in s:
            for i, x in enumerate(v):
                errs += validate(x, s["items"], f"{path}/{i}")
    if isinstance(v, dict):
        for r in s.get("required", []):
            if r not in v:
                errs.append(f"{path}: missing {r}")
        props = s.get("properties", {})
        for k, x in v.items():
            if k in props:
                errs += validate(x, props[k], f"{path}/{k}")
            elif s.get("additionalProperties") is False:
                errs.append(f"{path}: unknown field {k}")
    return errs


failures = 0


def expect(name, inp, ok):
    global failures
    errs = validate(inp, schema)
    good = (not errs) == ok
    failures += not good
    shown = "" if not errs else f"  -> {errs[0]}"
    print(f"{'PASS' if good else 'FAIL'}: {name} ({'valid' if not errs else 'rejected'}){shown if (not good or not ok) else ''}")


# 1. complete examples in the spec
blocks = re.findall(r"```json\n(.*?)```", spec, re.S)
n = 0
for b in blocks:
    try:
        obj = json.loads(b)
    except ValueError:
        continue
    if isinstance(obj, dict) and {"student", "transcript", "schedule"} <= set(obj):
        n += 1
        expect(f"spec example #{n}", obj, True)
print(f"({n} complete examples found in the spec)")

# 2. Ben's cases, with the new required field added
for c in ben:
    inp = copy.deepcopy(c["input"])
    inp["student"]["registered_crns"] = []
    expect(f"ben case {c['case_id']} + registered_crns", inp, True)
bare = copy.deepcopy(ben[0]["input"])
expect("ben case sem_001 WITHOUT registered_crns", bare, False)

# 3. synthetic students
base = copy.deepcopy(ben[0]["input"])
bad = 0
for r in synth:
    inp = {"student": r["student"], "transcript": r["transcript"], "program_requirements": [],
           "schedule": {"term": "Spring 2027", "sections": []}, "prompt": "placeholder"}
    if validate(inp, schema):
        bad += 1
        print("synthetic invalid:", r["student"]["student_id"], validate(inp, schema)[:2])
failures += bad
print(f"{'PASS' if not bad else 'FAIL'}: {len(synth)} synthetic students ({len(synth) - bad} valid)")

# 4. must be rejected
def mutate(f):
    t = copy.deepcopy(base)
    t["student"]["registered_crns"] = []
    f(t)
    return t

sec0 = lambda t: t["schedule"]["sections"][0]
req0 = lambda t: t["program_requirements"][0]
expect("answer key inside input", mutate(lambda t: t.update(answer=["12345"])), False)
expect("grade on in-progress course", mutate(lambda t: t["transcript"]["courses_in_progress"][0].update(grade="A")), False)
expect("crn with a space", mutate(lambda t: sec0(t).update(crn="123 45")), False)
expect("student_id with a space", mutate(lambda t: t["student"].update(student_id="S 1")), False)
expect("cancelled must be boolean", mutate(lambda t: sec0(t).update(cancelled="false")), False)
expect("negative waitlist_taken", mutate(lambda t: sec0(t).update(waitlist_taken=-1)), False)
expect("registered_crns repeats", mutate(lambda t: t["student"].update(registered_crns=["1", "1"])), False)
expect("attribute on a non-attribute rule", mutate(lambda t: req0(t).update(rule="all_of", attribute="ARTL")), False)
expect("credits_with_attribute without attribute", mutate(lambda t: req0(t).update(rule="credits_with_attribute", course_options=[])), False)
expect("credits_from with 0 credits", mutate(lambda t: req0(t).update(rule="credits_from", credit_hours=0)), False)
expect("all_of with empty course_options", mutate(lambda t: req0(t).update(rule="all_of", course_options=[])), False)
expect("credit_caps on all_of", mutate(lambda t: req0(t).update(rule="all_of", credit_caps=[{"course_options": ["CS05000"], "max_credits": 3}])), False)
expect("mutual_exclusions group of one", mutate(lambda t: t.update(mutual_exclusions=[["CS05000"]])), False)
expect("prerequisite without minimum_grade", mutate(lambda t: t.update(prerequisites=[{"course_id": "CS05000", "requires": ["CS04113"]}])), False)
# and a few that must be accepted
expect("credits_with_attribute with empty options", mutate(lambda t: req0(t).update(rule="credits_with_attribute", attribute="ARTL", course_options=[])), True)
expect("variable-credit section", mutate(lambda t: sec0(t).update(credit_hours={"min": 1, "max": 3})), True)
expect("valid mutual_exclusions", mutate(lambda t: t.update(mutual_exclusions=[["CS05000", "MATH03000"]])), True)

print("\nFAILURES:", failures)
sys.exit(1 if failures else 0)
