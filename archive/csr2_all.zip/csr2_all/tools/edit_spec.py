"""Targeted edits to main's input_format_specv5.md, bringing it to 0.5.
Keeps everything the group wrote; every edit asserts it matched exactly once.
usage: edit_spec.py <main_spec.md> <out_spec.md>
"""
import sys
from pathlib import Path

text = Path(sys.argv[1]).read_text(encoding="utf-8")


def sub(old, new, count=1):
    global text
    assert text.count(old) == count, f"expected {count} match(es), found {text.count(old)}: {old[:60]!r}"
    text = text.replace(old, new)


def after_line(anchor, extra):
    """Insert `extra` (one or more lines) right after the single line equal to `anchor`."""
    sub(anchor + "\n", anchor + "\n" + extra + "\n")


ATTR_ROW = ("| `attributes` | array of string | Optional | Catalog attributes the course carries, e.g. `ARTL` "
            "(*provisional*, used by `credits_with_attribute` requirements). |")

sub("**Version:** 0.4.1 (draft)", "**Version:** 0.5 (draft)")

# Top-level structure
after_line("| `prompt` | string | Required | The student's natural-language request. |",
           "| `prerequisites` | array | Optional | Courses that must be earned first (*provisional*, see \"Prerequisites, equivalents, exclusions and graduation rules\"). |\n"
           "| `course_equivalents` | array | Optional | Groups of course ids that are the same course under different catalog years (*provisional*). |\n"
           "| `mutual_exclusions` | array | Optional | Groups of course ids of which only one may be taken for credit (*provisional*, not yet enforced). |\n"
           "| `graduation_rules` | object | Optional | Graduation-wide credit and GPA rules (*provisional*).|")

# Student
sub("| `student_id` | string | Required | Anonymized unique identifier, e.g. `S001`. Never a real student id. |",
    "| `student_id` | string | Required | Anonymized unique identifier, e.g. `S001`. Never a real student id. No whitespace, because it becomes `student_id` in the registration message. |")
sub("- **`crn`** is a string, e.g. `\"10067\"`.", "- **`crn`** is a string with no whitespace, e.g. `\"10067\"`.")

# Transcript rows
after_line("| `credit_hours` | number | Required | Credits attempted. |", ATTR_ROW)
after_line("| `credit_hours` | number | Required | Credits accepted. |", ATTR_ROW)
after_line("| `credit_hours` | number | Required | Credits being taken. |", ATTR_ROW)

# Requirements
after_line("| `notes` | string | Optional | Free text. Not used by the checker. |",
           "| `attribute` | string | Optional | For `credits_with_attribute`: the attribute a course must carry. Required with that rule and allowed only with it (*provisional*). |\n"
           "| `repeatable` | array of string | Optional | Courses whose credits count every time they are earned. Otherwise only the best attempt counts (*provisional*). |\n"
           "| `credit_caps` | array | Optional | Entries of `{\"course_options\": [...], \"max_credits\": n}`: at most that many credits from those courses count. Only on `credits_from` and `credits_with_attribute` (*provisional*). |\n"
           "| `exclusive` | boolean | Optional | If `true`, a course used here cannot also count toward another `exclusive` requirement. By default one course may count toward several requirements (*provisional*). |")
after_line("| `credits_from` | Earned credits from `course_options`, each at or above `minimum_grade`, total at least `credit_hours`. |",
           "| `credits_with_attribute` | Earned credits of courses carrying `attribute`, each at or above `minimum_grade`, total at least `credit_hours`. `course_options` may then be empty (*provisional*). |")

# Section
sub("| `credit_hours` | number | Required | Credits for the section. |",
    "| `credit_hours` | number or `{min, max}` | Required | Credits for the section. A `{\"min\": 1, \"max\": 3}` object marks a variable-credit section; the range is shown to the model but not checked (*provisional*). |")
after_line("| `reserved_seats_left` | integer | Optional | Reserved seats not yet used (Section Tally: Left Reserved). |",
           "| `attributes` | array of string | Optional | Catalog attributes the section carries (*provisional*). |")

# New section, before ## Schedule
NEW_SECTION = """## Prerequisites, equivalents, exclusions and graduation rules

*Provisional.* Added in 0.5 from the checker work on the test branch, to fill open items 4, 6 and 7. All four top-level fields are optional.

### `prerequisites`

An array. Before taking `course_id`, every course in `requires` must be earned at or above `minimum_grade`. A course still in progress does not satisfy a prerequisite, because it has no grade yet. Registering for a course whose prerequisite is unmet is a consistency error.

| Field | Type | Required | Description |
|---|---|---|---|
| `course_id` | string | Required | The course that has the prerequisite. One entry per course. |
| `requires` | array of string | Required | Courses that must all be earned. At least one, no repeats. |
| `minimum_grade` | string | Required | Lowest passing letter grade that satisfies it. |

"This or that" prerequisites cannot be expressed yet (open item 12).

### `course_equivalents`

An array of groups. Each group lists two or more `course_id`s that are the same course under different catalog years. An equivalent satisfies a requirement or a prerequisite. A course is in at most one group.

### `mutual_exclusions`

An array of groups. Each group lists two or more `course_id`s of which a student may take only one for credit. Shown to the model; the checker does not enforce it yet (open item 13).

### `graduation_rules`

An object whose fields are all optional. GPA and credit totals are derived from the transcript, never stored.

| Field | Type | Description |
|---|---|---|
| `total_credits` | number | Earned credits needed to graduate. |
| `minimum_gpa` | number | Minimum GPA, 0 to 4. |
| `residency_credits` | number | Credits that must be earned at this institution. |

"""
sub("## Schedule\n", NEW_SECTION + "## Schedule\n")

# Validation rules
sub("### Checked by a reviewer\n",
    """### Added in 0.5

Checked by the JSON Schema:

15. `attribute` is present on a requirement if and only if its `rule` is `credits_with_attribute`.
16. `credit_caps` appears only on `credits_from` and `credits_with_attribute` requirements.
17. `course_options` has at least one entry unless the rule is `credits_with_attribute`.
18. `crn`, `student_id`, `req_id` and `attribute` contain no whitespace.

Checked by a validator script:

19. A course has at most one `prerequisites` entry and appears in at most one `course_equivalents` group.
20. A variable-credit section has `min` at most `max`.

### Checked by a reviewer
""")

# Open items
after_line("11. **Waitlists and reserved seats.** Stored as optional fields, but whether a registration to a full section with an open waitlist is valid is undecided. The v1 checker ignores them.",
           "12. **Alternative prerequisites.** `prerequisites` means every listed course is required. \"This or that\" is not expressible. Added in 0.5, partly answering item 4.\n"
           "13. **`mutual_exclusions` enforcement.** The field is in the schema and shown to the model, but no checker tier rejects a cart that violates it, and no test case exercises it.\n"
           "14. **Items 4, 6 and 7 are partly answered by provisional 0.5 fields.** Prerequisites are a consistency rule (item 4). Attribute requirements, repeatable courses, credit caps, one course counting toward several requirements, variable-credit sections and equivalents are represented (item 6). Graduation-wide rules are represented (item 7). Free electives are not. None of this is a group decision yet.")

# Changelog
sub("|---|---|---|\n| 0.4.1 |",
    "|---|---|---|\n| 0.5 | 2026-10-14 | Merged the checker work from the test branch into this spec and `input_format_schema.json`: `prerequisites`, `course_equivalents`, `mutual_exclusions`, `graduation_rules`, `attributes`, the `credits_with_attribute` rule, requirement fields `attribute`, `repeatable`, `credit_caps`, `exclusive`, variable-credit sections. Brought the schema up to this spec's 0.4 fields (`student.registered_crns`, `schedule.term_code`, the Section Tally section fields). Schema now enforces rule 6 and the new cross-field rules; ids may not contain whitespace. New open items 12 to 14. `registered_crns` is required, so existing case files need `\"registered_crns\": []`. |\n| 0.4.1 |")

# main's spec uses CRLF line endings; keep them so the diff shows only the real edits.
Path(sys.argv[2]).write_bytes(text.replace("\n", "\r\n").encode("utf-8"))
print("wrote", sys.argv[2])
