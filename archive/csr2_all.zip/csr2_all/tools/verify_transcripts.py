"""Independent re-check of synthetic_transcripts.json, written separately from the
generator's own check. Replays each transcript chronologically from the JSON alone.
usage: python3 -I verify_transcripts.py <synthetic_transcripts.json> <catalog_json> <wrapped_cases_out.json>
The catalog comes from a JSON dump of the generator's CATALOG (course -> prerequisites).
"""
import collections
import json
import sys

records = json.load(open(sys.argv[1], encoding="utf-8"))
catalog = json.load(open(sys.argv[2], encoding="utf-8"))
ORDER = {"Spring": 1, "Summer": 2, "Fall": 3}
PASS = ["A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-"]
problems = []

for r in records:
    sid = r["student"]["student_id"]
    t = r["transcript"]
    earned_ok = {c["course_id"] for c in t["transfer_courses"]}      # satisfies prerequisites
    earned_any = set(earned_ok)
    by_term = collections.defaultdict(list)
    for c in t["completed_courses"]:
        y = int(c["term"].split()[1])
        by_term[(y, ORDER[c["term"].split()[0]])].append(c)
        if c["term"] == "Fall 2026":
            problems.append(f"{sid}: completed course in the current term")
    for term in sorted(by_term):
        for c in by_term[term]:
            cid = c["course_id"]
            if cid in earned_any:
                problems.append(f"{sid}: {cid} retaken after being earned ({c['term']})")
            for p in catalog[cid]:
                if p not in earned_ok:
                    problems.append(f"{sid}: {cid} in {c['term']} without {p} earned at C- or better earlier")
        for c in by_term[term]:                                   # only now do this term's results count
            if c["grade"] in PASS:
                earned_any.add(c["course_id"])
                if PASS.index(c["grade"]) <= PASS.index("C-"):
                    earned_ok.add(c["course_id"])
    for c in t["courses_in_progress"]:
        if c["term"] != "Fall 2026":
            problems.append(f"{sid}: in-progress course not in Fall 2026")
        if "grade" in c:
            problems.append(f"{sid}: in-progress course has a grade")
        if c["course_id"] in earned_any:
            problems.append(f"{sid}: {c['course_id']} in progress but already earned")
        for p in catalog[c["course_id"]]:
            if p not in earned_ok:
                problems.append(f"{sid}: in-progress {c['course_id']} lacks {p}")
    ids = [c["course_id"] for c in t["courses_in_progress"]]
    if len(ids) != len(set(ids)):
        problems.append(f"{sid}: duplicate in-progress course")

# Stats
tags = collections.Counter(tag for r in records for tag in r["tags"])
grades = collections.Counter(c["grade"] for r in records for c in r["transcript"]["completed_courses"])
n_rows = sum(len(r["transcript"]["completed_courses"]) for r in records)
print("students", len(records), "| completed rows", n_rows,
      "| in-progress rows", sum(len(r["transcript"]["courses_in_progress"]) for r in records),
      "| transfer rows", sum(len(r["transcript"]["transfer_courses"]) for r in records))
print("tags:", dict(sorted(tags.items())))
print("grades:", {g: grades[g] for g in PASS + ["F", "W"] if grades[g]})
gpas = [r["summary"]["gpa"] for r in records if r["summary"]["gpa"] is not None]
print("gpa min/mean/max:", min(gpas), round(sum(gpas) / len(gpas), 2), max(gpas))
print("earned credits min/max:", min(r["summary"]["earned_credits"] for r in records),
      max(r["summary"]["earned_credits"] for r in records))
print("PROBLEMS:", problems if problems else "none")

# Wrap each student into a full input (placeholder requirements/schedule/prompt) for schema validation.
cases = [{"case_id": r["student"]["student_id"],
          "input": {"student": r["student"], "transcript": r["transcript"], "program_requirements": [],
                    "schedule": {"term": "Fall 2026", "sections": []}, "prompt": "placeholder"}}
         for r in records]
json.dump(cases, open(sys.argv[3], "w", encoding="utf-8"))
sys.exit(1 if problems else 0)
