"""Merges main's input_format_schema.json with the extra fields from Ben's branch.

usage: build_merged_schema.py <main_schema.json> <out_schema.json>

Everything main's schema already says is kept (names, camelCase $defs, patterns, enums).
Added, all additive except where noted:
  * from main's own spec v0.4.1, missing from its schema: student.registered_crns,
    schedule.term_code, and the Section Tally section fields;
  * from the checker work on Ben's branch: prerequisites, course_equivalents,
    mutual_exclusions, graduation_rules, attributes, the extra requirement fields and the
    credits_with_attribute rule, variable-credit sections;
  * cross-field rules the spec lists as schema-checked, written as if/then: attribute goes
    with credits_with_attribute, credit_caps only on the credit rules, credits_from needs
    credit_hours > 0 (spec rule 6).
Tightened on purpose: student_id, crn, req_id and attribute may not contain whitespace
(the registration message schema already requires this of student_id and crn).
"""
import json
import sys
from pathlib import Path

schema = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
defs = schema["$defs"]

NO_SPACE = "^\\S+$"

schema["$id"] = "https://example.edu/registration/input-format/0.5/schema.json"
schema["title"] = "Registration Input Format (draft 0.5)"
schema["description"] = (
    "One registration situation. Everything except `prompt` is state sent to the model; "
    "`prompt` is the intent. Rules that span several fields (unique crn and req_id, seats, "
    "registered_crns matching a crn, meeting times, waitlist and reserved-seat bounds) "
    "are checked by a validator script, not by this schema.")
props = schema["properties"]
props["prerequisites"] = {
    "description": "Courses that must be earned first. One entry per course. Enforced as a consistency rule.",
    "type": "array", "items": {"$ref": "#/$defs/prerequisite"}}
props["course_equivalents"] = {
    "description": ("Each group lists course ids that are the same course under different catalog "
                    "years. An equivalent satisfies a requirement or a prerequisite."),
    "type": "array",
    "items": {"type": "array", "minItems": 2, "uniqueItems": True, "items": {"$ref": "#/$defs/courseId"}}}
props["mutual_exclusions"] = {
    "description": ("Each group lists course ids of which a student may take only one for credit. "
                    "Shown to the model; not yet enforced by the checker."),
    "type": "array",
    "items": {"type": "array", "minItems": 2, "uniqueItems": True, "items": {"$ref": "#/$defs/courseId"}}}
props["graduation_rules"] = {"$ref": "#/$defs/graduationRules"}

# student
s = defs["student"]
s["properties"]["student_id"] = {
    "type": "string", "pattern": NO_SPACE,
    "description": "Anonymized unique id, no whitespace. Becomes student_id in the registration message."}
s["properties"]["registered_crns"] = {
    "description": ("Sections the student is already registered for in schedule.term. Each must match a "
                    "crn in schedule.sections (script-checked). May be empty."),
    "type": "array", "uniqueItems": True, "items": {"type": "string", "pattern": NO_SPACE}}
s["required"].append("registered_crns")

# transcript rows: attributes
ATTR = {"$ref": "#/$defs/attributes"}
for name in ("completedCourse", "transferCourse", "inProgressCourse"):
    defs[name]["properties"]["attributes"] = ATTR

# requirement
r = defs["requirement"]
rp = r["properties"]
rp["req_id"] = {"type": "string", "pattern": NO_SPACE}
rp["rule"] = {"enum": ["all_of", "any_of", "credits_from", "credits_with_attribute"],
              "description": ("all_of / any_of / credits_from as in the spec; credits_with_attribute is met by "
                              "credit_hours credits of courses carrying `attribute`.")}
rp["course_options"].pop("minItems")        # moved into the conditional below
rp["attribute"] = {"type": "string", "pattern": NO_SPACE,
                   "description": "For credits_with_attribute: the attribute a course must carry. Only with that rule."}
rp["repeatable"] = {"type": "array", "uniqueItems": True, "items": {"$ref": "#/$defs/courseId"},
                    "description": "Courses whose credits count every time they are earned. Otherwise only the best attempt counts."}
rp["credit_caps"] = {
    "description": "For the credit rules: at most max_credits from these courses count.",
    "type": "array",
    "items": {"type": "object", "required": ["course_options", "max_credits"], "additionalProperties": False,
              "properties": {"course_options": {"type": "array", "minItems": 1, "items": {"$ref": "#/$defs/courseId"}},
                             "max_credits": {"$ref": "#/$defs/creditHours"}}}}
rp["exclusive"] = {"type": "boolean",
                   "description": ("True if a course used here cannot also count toward another exclusive "
                                   "requirement. By default one course may count toward several requirements.")}
r["allOf"] = [
    {"if": {"required": ["rule"], "properties": {"rule": {"enum": ["all_of", "any_of", "credits_from"]}}},
     "then": {"properties": {"course_options": {"minItems": 1}}}},
    {"if": {"required": ["rule"], "properties": {"rule": {"const": "credits_from"}}},
     "then": {"properties": {"credit_hours": {"exclusiveMinimum": 0}}}},
    {"if": {"required": ["rule"], "properties": {"rule": {"const": "credits_with_attribute"}}},
     "then": {"required": ["attribute"]}},
    {"if": {"required": ["attribute"]},
     "then": {"properties": {"rule": {"const": "credits_with_attribute"}}}},
    {"if": {"required": ["credit_caps"]},
     "then": {"properties": {"rule": {"enum": ["credits_from", "credits_with_attribute"]}}}},
]

# schedule and section
defs["schedule"]["properties"]["term_code"] = {
    "type": "string", "minLength": 1,
    "description": "Registrar term code as printed by Section Tally, e.g. 202710."}
sec = defs["section"]["properties"]
sec["crn"] = {"type": "string", "pattern": NO_SPACE,
              "description": "Unique section id. The model's registration message must use it."}
sec["credit_hours"] = {"oneOf": [
    {"$ref": "#/$defs/creditHours"},
    {"type": "object", "required": ["min", "max"], "additionalProperties": False,
     "properties": {"min": {"$ref": "#/$defs/creditHours"}, "max": {"$ref": "#/$defs/creditHours"}}}],
    "description": "Credits, or a {min, max} range for a variable-credit section (the range is shown, not checked)."}
sec["instructors"] = {"type": "array", "items": {"type": "string", "minLength": 1},
                      "description": "Instructor names. Use fictional names in case files."}
sec["cancelled"] = {"type": "boolean", "description": "True if the section is cancelled. Defaults to false."}
sec["part_of_term"] = {"type": "string", "minLength": 1, "description": "Part of term, free text as printed."}
for name, text in (("waitlist_capacity", "Waitlist capacity (Section Tally: Wait Cap)."),
                   ("waitlist_taken", "Students on the waitlist (Section Tally: Wait Enrolled)."),
                   ("reserved_seats_total", "Seats reserved for a group (Section Tally: Max Reserved)."),
                   ("reserved_seats_left", "Reserved seats not yet used (Section Tally: Left Reserved).")):
    sec[name] = {"type": "integer", "minimum": 0, "description": text}
sec["attributes"] = ATTR

# new defs
defs["attributes"] = {
    "description": "Catalog attributes a course carries, e.g. a general-education area. Used by credits_with_attribute.",
    "type": "array", "uniqueItems": True, "items": {"type": "string", "pattern": NO_SPACE}}
defs["prerequisite"] = {
    "description": "Before taking course_id, every course in requires must be earned at or above minimum_grade. A course in progress does not count.",
    "type": "object", "required": ["course_id", "requires", "minimum_grade"], "additionalProperties": False,
    "properties": {
        "course_id": {"$ref": "#/$defs/courseId"},
        "requires": {"type": "array", "minItems": 1, "uniqueItems": True, "items": {"$ref": "#/$defs/courseId"}},
        "minimum_grade": {"$ref": "#/$defs/letterGrade"}}}
defs["graduationRules"] = {
    "description": "Graduation-wide rules. Each field is optional. GPA and credit totals are derived from the transcript, never stored.",
    "type": "object", "additionalProperties": False,
    "properties": {
        "total_credits": {"type": "number", "minimum": 0, "description": "Earned credits needed to graduate."},
        "minimum_gpa": {"type": "number", "minimum": 0, "maximum": 4},
        "residency_credits": {"type": "number", "minimum": 0,
                              "description": "Credits that must be earned at this institution."}}}

Path(sys.argv[2]).write_text(json.dumps(schema, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print("wrote", sys.argv[2])
