# Synthetic transcripts (task 1.2b)

24 fictional Computer Science students, each with a transcript in the registration input
format (`input_format_schema.json`, draft 0.5, the merged schema in `main`). Everything is
invented: no real student, grade or record. Each `student` has `registered_crns: []`,
because the schema requires the field and a transcript alone has no sections to register for.

| File | Content |
|---|---|
| `synthetic_transcripts.json` | One record per student: `student`, `transcript` (both exactly as the input schema defines them), plus `summary` and `tags` (extras for case authors; **not** part of the input, do not send them to a model). |
| `synthetic_transcripts.csv` | The same courses, one row per course: `student_id, status, term, institution, course_id, title, grade, credit_hours, campus, level, attributes`. `status` is `completed`, `transfer` or `in_progress`. |
| `generate_transcripts.py` | Regenerates both. `python generate_transcripts.py --count 40 --seed 7 --out-dir out` |

## What is in the set

- 24 students; entry terms Fall 2022 to Fall 2026 (4 are first-semester students). Current term is Fall 2026, so each student's latest courses are `courses_in_progress`.
- 411 completed-course rows, 94 in progress, 12 transfer rows (grade `TA`).
- Covers: withdrawn then retaken (the spec's CS04222 example is student S200), repeated failures, withdrawals not yet retaken, transfer credit satisfying prerequisites, low GPA.

`tags` per student: `has_withdrawal`, `has_failure`, `retook_and_passed`, `unresolved_w_or_f` (latest attempt of some course is W or F), `has_transfer`, `first_semester`, `senior_standing` (90+ earned credits), `gpa_below_2`. `summary` holds `earned_credits` and `gpa`, counting each course once by its best attempt.

## Rules every transcript follows (checked)

- A course is taken only after its prerequisites were earned at C- or better in an earlier term, or by transfer.
- A course already passed is never taken again; a W or F is retaken later.
- At most 17 credits a term; no course twice in one term; no in-progress course already earned.
- Every student and transcript validates against `input_format_schema.json` (draft 0.5).

## Limits

- **The catalog is fictional.** 35 courses. Ids and titles that already appear in the repo's cases are reused (CS04113, CS04114, CS04222, PHYS00220, ART02100, ...). The rest are made up, as are the prerequisites beyond the four in case `sem_004`, and attributes other than `ARTL`. Swap `CATALOG` for real SectionTally rows once the CSV is loaded.
- Grade rates are arbitrary (about 7% of attempts are W, 4% F).
- These are transcripts only. A full test input also needs `program_requirements`, a `schedule` and a `prompt`.
- No `course_equivalents` or `mutual_exclusions` are used, and prerequisites are all "every listed course".
