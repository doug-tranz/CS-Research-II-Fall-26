#!/usr/bin/env python3
"""Synthetic student transcripts in the registration input format (schema v1.0).

Every student, course grade and transfer credit here is invented. The course catalog
is a small fictional one: ids and titles that already appear in the repo's cases
(CS04113, CS04222, PHYS00220, ART02100, ...) are reused so the data lines up with
them; the rest are made up. When the team has the SectionTally CSV, replace CATALOG
with rows from it and regenerate.

Each transcript is built term by term from the first term to Spring 2026, with the
current term (Fall 2026) as courses in progress. A course is only taken once its
prerequisites were earned at C- or better in an EARLIER term (or by transfer), a
failed or withdrawn course is retaken later, and a course already passed is never
taken again.

Usage:
    python generate_transcripts.py                      # 24 students, seed 2026
    python generate_transcripts.py --count 40 --seed 7 --out-dir out
Writes synthetic_transcripts.json and synthetic_transcripts.csv to --out-dir.
"""
import argparse
import csv
import json
import random
from pathlib import Path

CURRENT_TERM = "Fall 2026"
LAST_COMPLETED = (2026, "Spring")
PASSING = ["A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-"]   # best to worst
POINTS = dict(zip(PASSING, [4.0, 3.7, 3.3, 3.0, 2.7, 2.3, 2.0, 1.7, 1.3, 1.0, 0.7]), F=0.0)
PREREQ_MIN = "C-"
MAX_TERM_CREDITS = 17

# (course_id, title, credits, prerequisites, attributes, tier)
# tier orders when a course is usually taken: 1 intro ... 4 capstone.
CATALOG = [
    ("COMP01111", "College Composition I", 3, [], [], 1),
    ("COMP01112", "College Composition II", 3, ["COMP01111"], [], 2),
    ("MATH01130", "Calculus I", 4, [], [], 1),
    ("MATH01131", "Calculus II", 4, ["MATH01130"], [], 2),
    ("MATH02100", "Discrete Mathematics", 3, ["MATH01130"], [], 2),
    ("MATH03000", "Applied Mathematics", 3, ["MATH01131"], [], 3),
    ("STAT02260", "Statistics", 3, [], [], 2),
    ("PHYS00220", "INTRODUCTORY MECHANICS", 4, [], [], 1),
    ("PHYS00221", "Electricity and Magnetism", 4, ["PHYS00220"], [], 2),
    ("CS04113", "INTRO OBJ-ORIENT PRGRMMNG", 4, [], [], 1),
    ("CS04114", "OBJ-ORIENT PRGRM/DATA ABSTR", 3, ["CS04113"], [], 2),
    ("CS04222", "DATA STRUCT/ALGORIM", 4, ["CS04113"], [], 2),
    ("CS03351", "Computer Organization", 3, ["CS04113"], [], 3),
    ("CS02435", "Web Application Development", 3, ["CS04114"], [], 3),
    ("CS01303", "Scientific Computing", 3, ["PHYS00220"], [], 3),
    ("CS02480", "Database Systems", 3, ["CS04114"], [], 3),
    ("CS01395", "Special Topics in Computing", 3, [], [], 3),
    ("CS05000", "Introduction to Software Engineering", 3, ["CS04222"], [], 3),
    ("CS05100", "Operating Systems", 3, ["CS04222"], [], 3),
    ("CS05200", "Computer Networks", 3, ["CS03351"], [], 3),
    ("CS07450", "Advanced Algorithms", 3, ["CS04222"], [], 4),
    ("CS06000", "Senior Capstone I", 3, ["CS05000"], [], 4),
    ("CS06001", "Senior Capstone II", 3, ["CS06000"], [], 4),
    ("ART02100", "Drawing I", 3, [], ["ARTL"], 1),
    ("MUS01100", "Music Appreciation", 3, [], ["ARTL"], 2),
    ("HIST01100", "World History", 3, [], ["HUML"], 1),
    ("PHIL01100", "Introduction to Ethics", 3, [], ["HUML"], 2),
    ("ENGL02200", "Introduction to Literature", 3, [], ["HUML"], 2),
    ("PSYC01100", "General Psychology", 3, [], ["SOCL"], 1),
    ("SOC01100", "Introduction to Sociology", 3, [], ["SOCL"], 2),
    ("ECON01100", "Principles of Economics", 3, [], ["SOCL"], 2),
    ("COMM01100", "Public Speaking", 3, [], [], 1),
    ("SPAN01101", "Elementary Spanish I", 3, [], [], 2),
    ("BIOL01100", "Biology for Science Majors", 4, [], [], 2),
    ("CHEM01100", "General Chemistry I", 4, [], [], 2),
]
BY_ID = {c[0]: c for c in CATALOG}
DEPENDENTS = {cid: [c[0] for c in CATALOG if cid in c[3]] for cid in BY_ID}
TRANSFERABLE = ["COMP01111", "MATH01130", "PHYS00220", "PSYC01100", "HIST01100",
                "STAT02260", "CHEM01100", "BIOL01100", "COMM01100"]
INSTITUTIONS = ["Example County College", "Sample Community College", "Fictional State University"]
CAMPUSES = ["Glassboro", "Camden", "Online"]
MINORS = ["Mathematics", "Statistics", "Philosophy", "Psychology"]

# Grade tables per student strength, indexed like PASSING (weights need not sum to 1).
GRADE_WEIGHTS = {
    "strong": [30, 22, 18, 12, 8, 5, 3, 1, 0.5, 0.3, 0.2],
    "average": [14, 12, 14, 16, 12, 10, 9, 5, 3, 3, 2],
    "weak": [4, 5, 7, 10, 12, 14, 16, 12, 8, 7, 5],
}
P_WITHDRAW = {"strong": 0.03, "average": 0.06, "weak": 0.12}
P_FAIL = {"strong": 0.01, "average": 0.04, "weak": 0.11}

# Scenarios forced onto specific students so the set always covers the interesting cases.
# student index -> {course: outcomes of its first attempts, in order}
FORCED = {
    0: {"CS04222": ["W", "B"]},                 # withdrew, retook, passed (the spec's own example)
    1: {"CS04113": ["F", "B-"]},                # failed an intro course, retook it
    2: {"MATH01131": ["F", "F", "C"]},          # failed twice before passing
    3: {"CS04114": ["W", "W", "B+"]},           # withdrew twice
    5: {"MATH01130": ["F", "C+"]},              # gateway math failure in year two
    6: {"CS04222": ["W"], "STAT02260": ["W"]},  # two withdrawals, not yet retaken
    10: {"CS04113": ["W", "A-"]},
}
ENTRY_YEARS = [2022] * 5 + [2023] * 5 + [2024] * 5 + [2025] * 5 + [2026] * 4


def term_label(year, season):
    return f"{season} {year}"


def completed_terms(entry_year):
    """Fall entry_year through Spring 2026, in order. Empty for a 2026 entrant."""
    terms = []
    for year in range(entry_year, LAST_COMPLETED[0]):
        terms.append((year, "Fall"))
        terms.append((year + 1, "Spring"))
    return terms


class History:
    """What a student has earned so far, by course."""

    def __init__(self):
        self.attempts = {}      # course -> list of grades (completed courses only)
        self.transfer = set()

    def best_index(self, course):
        if course in self.transfer:
            return -1
        grades = [PASSING.index(g) for g in self.attempts.get(course, []) if g in PASSING]
        return min(grades) if grades else None

    def earned(self, course):
        return self.best_index(course) is not None

    def meets_prereq(self, course):
        best = self.best_index(course)
        return best is not None and best <= PASSING.index(PREREQ_MIN)

    def eligible(self, course):
        return (not self.earned(course)
                and all(self.meets_prereq(p) for p in BY_ID[course][3]))


def draw_grade(rng, course, strength):
    """One outcome: a passing letter, F or W. Courses others depend on never pass below C-."""
    roll = rng.random()
    if roll < P_WITHDRAW[strength]:
        return "W"
    if roll < P_WITHDRAW[strength] + P_FAIL[strength]:
        return "F"
    weights = list(GRADE_WEIGHTS[strength])
    if DEPENDENTS[course]:
        for i in range(PASSING.index(PREREQ_MIN) + 1, len(weights)):
            weights[i] = 0
    return rng.choices(PASSING, weights)[0]


def pick_courses(rng, history, taken_now, strength, forced=None):
    """Choose this term's load from the eligible courses, intro courses first.
    A course with forced outcomes still to play goes first, so its scenario happens."""
    forced = forced or {}
    pool = [c for c in BY_ID if history.eligible(c) and c not in taken_now]
    pool.sort(key=lambda c: BY_ID[c][5] + rng.uniform(0, 1.3) - (10 if forced.get(c) else 0))
    target = rng.choice([12, 13, 14, 15, 15, 16] if strength != "weak" else [9, 12, 12, 13])
    chosen, credits = [], 0
    for c in pool:
        if len(chosen) >= 5 or credits >= target:
            break
        if credits + BY_ID[c][2] <= MAX_TERM_CREDITS:
            chosen.append(c)
            credits += BY_ID[c][2]
    return chosen


def course_row(course, term, campus, grade=None):
    cid, title, credits, _, attrs, _ = BY_ID[course]
    row = {"term": term, "course_id": cid, "campus": campus, "level": "UG", "title": title}
    if grade is not None:
        row["grade"] = grade
    row["credit_hours"] = credits
    if attrs:
        row["attributes"] = list(attrs)
    return row


def build_student(rng, index, entry_year):
    strength = rng.choices(["strong", "average", "weak"], [3, 5, 2])[0]
    home = rng.choices(CAMPUSES, [8, 1, 1])[0]
    forced = {c: list(v) for c, v in FORCED.get(index, {}).items()}
    history = History()

    # Transfer credit, mostly for students who did not start in 2026.
    transfer = []
    if rng.random() < (0.45 if entry_year == 2026 else 0.3):
        for course in rng.sample(TRANSFERABLE, rng.choice([1, 1, 2])):
            cid, title, credits, _, attrs, _ = BY_ID[course]
            row = {"institution": rng.choice(INSTITUTIONS), "course_id": cid, "title": title,
                   "grade": "TA", "credit_hours": credits}
            if attrs:
                row["attributes"] = list(attrs)
            transfer.append(row)
            history.transfer.add(course)

    completed = []
    for year, season in completed_terms(entry_year):
        if completed and rng.random() < 0.07:       # a term off
            continue
        label = term_label(year, season)
        results = []
        for course in pick_courses(rng, history, set(), strength, forced):
            outcome = forced[course].pop(0) if forced.get(course) else draw_grade(rng, course, strength)
            campus = home if rng.random() < 0.88 else rng.choice(CAMPUSES)
            completed.append(course_row(course, label, campus, outcome))
            results.append((course, outcome))
        for course, outcome in results:             # earned only AFTER the term ends
            history.attempts.setdefault(course, []).append(outcome)

    in_progress = [course_row(c, CURRENT_TERM, home)
                   for c in pick_courses(rng, history, set(), strength)]

    # registered_crns is required by the input schema (v0.5+). Transcript-only data has no
    # sections to register for yet, so it is empty; fill it in when pairing with a schedule.
    student = {"student_id": f"S{200 + index}", "degree": "Bachelor of Science",
               "major": "Computer Science", "program_id": "O701",
               "catalog_year": term_label(entry_year, "Fall"), "registered_crns": []}
    if rng.random() < 0.3:
        student["minor"] = rng.choice(MINORS)
    unused = [c for c, v in forced.items() if v]
    assert not unused, f"student {index}: forced outcomes never used: {unused}"
    return student, {"completed_courses": completed, "transfer_courses": transfer,
                     "courses_in_progress": in_progress}, strength


def summarize(transcript):
    """Earned credits and GPA, each course counted once by its best attempt."""
    best = {}
    for c in transcript["completed_courses"]:
        g = c["grade"]
        if g == "W":
            continue
        if c["course_id"] not in best or POINTS[g] > POINTS[best[c["course_id"]][0]]:
            best[c["course_id"]] = (g, c["credit_hours"])
    transfer_credits = sum(t["credit_hours"] for t in transcript["transfer_courses"])
    earned = sum(h for g, h in best.values() if g != "F") + transfer_credits
    graded = sum(h for g, h in best.values())
    gpa = round(sum(POINTS[g] * h for g, h in best.values()) / graded, 2) if graded else None
    return {"earned_credits": earned, "gpa": gpa}


def tags_for(transcript, summary):
    grades_by_course = {}
    for c in transcript["completed_courses"]:
        grades_by_course.setdefault(c["course_id"], []).append(c["grade"])
    tags = []
    if any("W" in g for g in grades_by_course.values()):
        tags.append("has_withdrawal")
    if any("F" in g for g in grades_by_course.values()):
        tags.append("has_failure")
    for course, g in grades_by_course.items():
        if len(g) > 1 and g[-1] in PASSING:
            tags.append("retook_and_passed")
            break
    if any(g and g[-1] in ("W", "F") for g in grades_by_course.values()):
        tags.append("unresolved_w_or_f")
    if transcript["transfer_courses"]:
        tags.append("has_transfer")
    if not transcript["completed_courses"]:
        tags.append("first_semester")
    if summary["earned_credits"] >= 90:
        tags.append("senior_standing")
    if summary["gpa"] is not None and summary["gpa"] < 2.0:
        tags.append("gpa_below_2")
    return tags


def check_sound(student, transcript):
    """Hard checks on the generated transcript; raises AssertionError on a problem."""
    sid = student["student_id"]
    order = {"Winter": 0, "Spring": 1, "Summer": 2, "Fall": 3}

    def key(term):
        season, year = term.split()
        return (int(year), order[season])

    best_before = {}
    for c in transcript["transfer_courses"]:
        best_before[c["course_id"]] = -1
    terms = sorted({c["term"] for c in transcript["completed_courses"]}, key=key)
    for term in terms:
        rows = [c for c in transcript["completed_courses"] if c["term"] == term]
        assert sum(r["credit_hours"] for r in rows) <= MAX_TERM_CREDITS, f"{sid} {term}: overloaded"
        assert len({r["course_id"] for r in rows}) == len(rows), f"{sid} {term}: course twice in a term"
        for r in rows:
            cid = r["course_id"]
            prior = best_before.get(cid)
            assert prior is None, f"{sid}: {cid} taken again after it was passed"
            for p in BY_ID[cid][3]:
                b = best_before.get(p)
                assert b is not None and b <= PASSING.index(PREREQ_MIN), \
                    f"{sid} {term}: {cid} taken without prerequisite {p}"
        for r in rows:
            if r["grade"] in PASSING:
                best_before[r["course_id"]] = min(best_before.get(r["course_id"], 99),
                                                  PASSING.index(r["grade"]))
    for c in transcript["courses_in_progress"]:
        cid = c["course_id"]
        assert cid not in best_before, f"{sid}: {cid} is in progress but already earned"
        for p in BY_ID[cid][3]:
            b = best_before.get(p)
            assert b is not None and b <= PASSING.index(PREREQ_MIN), \
                f"{sid}: in-progress {cid} lacks prerequisite {p}"
    assert sum(c["credit_hours"] for c in transcript["courses_in_progress"]) <= MAX_TERM_CREDITS


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--count", type=int, default=24)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--out-dir", default=".")
    args = ap.parse_args()
    rng = random.Random(args.seed)
    years = (ENTRY_YEARS * (args.count // len(ENTRY_YEARS) + 1))[:args.count]

    records = []
    for i, entry_year in enumerate(years):
        student, transcript, strength = build_student(rng, i, entry_year)
        check_sound(student, transcript)
        summary = summarize(transcript)
        records.append({"student": student, "transcript": transcript, "summary": summary,
                        "tags": tags_for(transcript, summary), "_strength": strength})

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    for r in records:
        r.pop("_strength")      # generator detail, not data
    (out / "synthetic_transcripts.json").write_text(
        json.dumps(records, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    cols = ["student_id", "status", "term", "institution", "course_id", "title", "grade",
            "credit_hours", "campus", "level", "attributes"]
    with open(out / "synthetic_transcripts.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in records:
            sid = r["student"]["student_id"]
            for status, rows in (("completed", r["transcript"]["completed_courses"]),
                                 ("transfer", r["transcript"]["transfer_courses"]),
                                 ("in_progress", r["transcript"]["courses_in_progress"])):
                for row in rows:
                    flat = {"student_id": sid, "status": status, **row}
                    flat["attributes"] = ";".join(row.get("attributes", []))
                    w.writerow({k: flat.get(k, "") for k in cols})
    print(f"wrote {len(records)} students to {out}")


if __name__ == "__main__":
    main()
