# Registration input format: specification v1.0

**Status:** finalized candidate for group sign-off. Companion to `registration_input.schema.json`,
which is the machine-readable source of truth. The field tables below are generated from that
file, so the two cannot disagree.

One input object describes one registration situation. Everything except `prompt` is sent to the
model as known state; `prompt` is sent as the intent. The answer key never goes in the input
(unknown fields are rejected, so an answer key placed inside one is caught).

## How the checker uses each part

| Part | Used by | Effect |
|---|---|---|
| `schedule` | Tier 3 | Section exists, has a seat, no time overlap with the student's enrollments or inside the cart, no two sections of one course. |
| `prerequisites` + `transcript` | Tier 3 | Registering for a course with an unmet prerequisite is a `consistency_error`. A course in progress does not satisfy one. |
| `program_requirements`, `graduation_rules`, `attributes` | Audit only | `registration.audit()` reports which requirements are met. Not part of scoring; Tier 4 compares to the case author's answer key. |
| `course_equivalents` | Prerequisites and audit | An equivalent satisfies a prerequisite or requirement. |
| `mutual_exclusions` | Model only | Shown to the model. **Not yet enforced by Tier 3.** |

## Fields

### Top level

| Field | Type | Required | Meaning |
|---|---|---|---|
| `student` | object (see student) | yes | Who is registering. |
| `transcript` | object (see transcript) | yes | Everything the student has taken, split by status: completed, transfer, in progress. |
| `program_requirements` | array of requirement | yes | The degree requirements the student is working toward. |
| `schedule` | object (see schedule) | yes | The term being registered for and every section on offer. |
| `prompt` | string | yes | The student's request in everyday language. Sent to the model as the intent, never as state. |
| `prerequisites` | array of prerequisite | no | Courses that must be earned first. One entry per course. Enforced at Tier 3. |
| `course_equivalents` | array of course-id groups | no | Each group lists course ids that are the same course under different catalog years. An equivalent satisfies a requirement or a prerequisite. |
| `graduation_rules` | object (see graduation_rules) | no | Graduation-wide rules. Each field is optional. |
| `mutual_exclusions` | array of course-id groups | no | Each group lists course ids of which a student may take only one for credit. Shown to the model; NOT yet enforced by Tier 3. |

### student

| Field | Type | Required | Meaning |
|---|---|---|---|
| `student_id` | string | yes | Unique id, no whitespace. Becomes `student_id` in the registration message. |
| `degree` | string | yes | Degree sought. |
| `major` | string | yes | Declared major. |
| `minor` | string | no | Declared minor, if any. |
| `program_id` | string | yes | Catalog program the requirements come from. |
| `catalog_year` | term (`Season YYYY`) | yes | Term of the catalog the student follows, as `Season YYYY`. |

### transcript

| Field | Type | Required | Meaning |
|---|---|---|---|
| `completed_courses` | array of completed course | yes | Courses with a final grade, including failed (F) and withdrawn (W) attempts. |
| `transfer_courses` | array of transfer course | yes | Credit accepted from other institutions. |
| `courses_in_progress` | array of course in progress | yes | Courses with no grade yet. Kept apart from completed courses because an in-progress course may still be withdrawn or failed, so it never counts as earned. |

### completed_courses item

| Field | Type | Required | Meaning |
|---|---|---|---|
| `term` | term (`Season YYYY`) | yes | Term the course was taken. |
| `course_id` | course id | yes | The course. |
| `campus` | string | no | Campus where it was taken. |
| `level` | enum: `UG`, `GR` | no | UG or GR. |
| `title` | string | no | Course title, for readability. |
| `grade` | enum: `A`, `A-`, `B+`, `B`, … | yes | Final grade, including F and W. Only passing grades satisfy a requirement or prerequisite. |
| `credit_hours` | number | yes | Credits attempted. |
| `attributes` | array | no | Catalog attributes the course carried. |

### transfer_courses item

| Field | Type | Required | Meaning |
|---|---|---|---|
| `institution` | string | yes | Institution the credit came from. |
| `course_id` | course id | yes | The course, as it maps here. |
| `title` | string | no | Course title, for readability. |
| `grade` | enum: `A`, `A-`, `B+`, `B`, … | yes | Grade received. `TA` is accepted transfer credit and meets every minimum grade. |
| `credit_hours` | number | yes | Credits accepted. |
| `attributes` | array | no | Catalog attributes the course carries. |

### courses_in_progress item

| Field | Type | Required | Meaning |
|---|---|---|---|
| `term` | term (`Season YYYY`) | yes | Term the student is taking it now. |
| `course_id` | course id | yes | The course. |
| `campus` | string | no | Campus. |
| `level` | enum: `UG`, `GR` | no | UG or GR. |
| `title` | string | no | Course title, for readability. |
| `credit_hours` | number | yes | Credits being attempted. |
| `attributes` | array | no | Catalog attributes the course carries. |

### program_requirements item

| Field | Type | Required | Meaning |
|---|---|---|---|
| `req_id` | string | yes | Unique id for the requirement, no whitespace. |
| `category` | string | yes | Group the requirement belongs to, e.g. core or elective. |
| `rule` | enum: `all_of`, `any_of`, `credits_from`, `credits_with_attribute` | yes | How it is met: all_of (every course in course_options), any_of (one of them), credits_from (credit_hours credits from them), credits_with_attribute (credit_hours credits of courses carrying `attribute`). |
| `course_options` | array of course id | yes | Courses that can count. Empty for credits_with_attribute. |
| `title` | string | no | Requirement title, for readability. |
| `credit_hours` | number | yes | Credits the requirement needs. |
| `minimum_grade` | enum: `A`, `A-`, `B+`, `B`, … | yes | Lowest passing grade that counts. Compared in the order of the passing_grade list. |
| `notes` | string | no | Free-text note. |
| `attribute` | string | no | For credits_with_attribute, the attribute a course must carry. Only with that rule. |
| `repeatable` | array of course id | no | Courses whose credits count every time they are earned. Otherwise only the best attempt counts. |
| `credit_caps` | array | no | For the credit rules: at most max_credits from the listed courses count. Not allowed on other rules. |
| `exclusive` | boolean | no | True if a course used here cannot also be used by another exclusive requirement. By default one course may count toward several requirements. |

### schedule

| Field | Type | Required | Meaning |
|---|---|---|---|
| `term` | term (`Season YYYY`) | yes | Term being registered for, as `Season YYYY`. |
| `sections` | array of section | yes | Every section on offer this term. |

### schedule.sections item

| Field | Type | Required | Meaning |
|---|---|---|---|
| `crn` | string | yes | Unique id of the section. The registration message's `sections` list holds these. |
| `course_id` | course id | yes | The course this section teaches. |
| `section` | string | yes | Section code within the course. |
| `title` | string | no | Course title, for readability. |
| `credit_hours` | any | yes | Credits, or a {min, max} range for a variable-credit section. The range is shown but not checked. |
| `seats_total` | integer | yes | Seats offered. |
| `seats_taken` | integer | yes | Seats already filled. Cannot exceed seats_total; the section is full when they are equal. |
| `campus` | string | yes | Campus where it meets. |
| `modality` | enum: `in-person`, `online`, `hybrid` | yes | in-person, online or hybrid. |
| `meetings` | array of meeting | yes | Meeting times. Two sections conflict when they share a day and their time ranges overlap. |
| `attributes` | array | no | Catalog attributes the section carries. |

### meetings item

| Field | Type | Required | Meaning |
|---|---|---|---|
| `days` | array | yes | Days of the week it meets, no repeats. |
| `start_time` | `h:mm AM/PM` | yes | Start, as h:mm AM/PM. |
| `end_time` | `h:mm AM/PM` | yes | End, as h:mm AM/PM. Must be after the start. |
| `type` | string | no | Optional label for the kind of meeting. |

### prerequisites item

| Field | Type | Required | Meaning |
|---|---|---|---|
| `course_id` | course id | yes | The course that has the prerequisite. One entry per course. |
| `requires` | array of course id | yes | Every course listed must be earned at or above minimum_grade first. A course in progress does not count. |
| `minimum_grade` | enum: `A`, `A-`, `B+`, `B`, … | yes | Lowest passing grade that satisfies the prerequisite. |

### graduation_rules

| Field | Type | Required | Meaning |
|---|---|---|---|
| `total_credits` | number | no | Earned credits needed to graduate. |
| `minimum_gpa` | number | no | Minimum GPA, 0 to 4. Derived from the transcript, never stored. |
| `residency_credits` | number | no | Credits that must be earned at this institution. |

## Rules a JSON Schema cannot express

Checked in `registration.validate_input()` after the schema passes:

- every `crn` is unique, and every `req_id` is unique;
- a course has at most one `prerequisites` entry, and appears in at most one `course_equivalents` group;
- `seats_taken` is at most `seats_total`; a variable-credit section has `min` at most `max`;
- a meeting ends after it starts;
- `attribute` appears on a requirement if and only if its rule is `credits_with_attribute`;
- `credit_caps` appears only on `credits_from` and `credits_with_attribute` requirements.

## Conventions

- **Course ids** are a subject code plus a five-character number, no space (`CS04113`). Always strings: leading zeros matter.
- **Terms** are `Season YYYY`. **Times** are `h:mm AM/PM`.
- **Grades** are compared highest to lowest: A, A-, B+, B, B-, C+, C, C-, D+, D, D-. `F` and `W` meet no minimum. `TA` (accepted transfer credit) meets every minimum.
- **In-progress courses** have their own list and no `grade` field. They never count as earned: the student may still withdraw or fail, and that changes whether later prerequisites are met. A withdrawn or failed attempt goes in `completed_courses` with grade `W` or `F`.
- **Section ids**: the model's registration message lists `crn` values.

## Minimal example

```json
{
  "student": {
    "student_id": "S100",
    "degree": "Bachelor of Science",
    "major": "Computer Science",
    "program_id": "P100",
    "catalog_year": "Fall 2026"
  },
  "transcript": {
    "completed_courses": [
      {
        "term": "Fall 2025",
        "course_id": "CS04113",
        "grade": "A",
        "credit_hours": 4
      },
      {
        "term": "Spring 2026",
        "course_id": "CS04222",
        "grade": "W",
        "credit_hours": 4
      }
    ],
    "transfer_courses": [],
    "courses_in_progress": [
      {
        "term": "Fall 2026",
        "course_id": "CS04114",
        "credit_hours": 3
      }
    ]
  },
  "program_requirements": [
    {
      "req_id": "ds",
      "category": "Major",
      "rule": "all_of",
      "course_options": [
        "CS04222"
      ],
      "credit_hours": 4,
      "minimum_grade": "C"
    }
  ],
  "schedule": {
    "term": "Fall 2026",
    "sections": [
      {
        "crn": "10001",
        "course_id": "CS04222",
        "section": "01",
        "credit_hours": 4,
        "seats_total": 30,
        "seats_taken": 12,
        "campus": "Glassboro",
        "modality": "in-person",
        "meetings": [
          {
            "days": [
              "Monday",
              "Wednesday"
            ],
            "start_time": "10:00 AM",
            "end_time": "11:15 AM"
          }
        ]
      }
    ]
  },
  "prompt": "Enroll me in the data structures course I withdrew from.",
  "prerequisites": [
    {
      "course_id": "CS04222",
      "requires": [
        "CS04113"
      ],
      "minimum_grade": "C"
    }
  ],
  "mutual_exclusions": [
    [
      "CS04222",
      "CS04223"
    ]
  ]
}
```

## Decisions carried in from the 10/9 and 10/12 meetings

| Decision | Where it landed |
|---|---|
| Merge prerequisites, mutual exclusions and equivalent courses into the canonical schema | `prerequisites` and `course_equivalents` were already present; `mutual_exclusions` is new in v1.0. |
| Keep in-progress courses as a separate field | `transcript.courses_in_progress` (unchanged). |
| JSON is the machine form, Markdown the readable spec, kept in step | This file is generated from the schema. |
| Every field gets a description | Added to the schema and to the tables above. |
| Align with the SectionTally CSV export | **Not done**: the CSV's columns were not available when this was written. See below. |

## Open items

1. **SectionTally alignment.** Compare the CSV headers with `schedule.sections` and `transcript`, and rename or add fields so a CSV row maps straight onto a section. Registration-specific data (Banner blocks, registration-time prerequisite enforcement) may not be in the CSV at all.
2. **Reconcile with Kolio's and Tyler's JSON.** v1.0 was built from the repo's schema. Any field in their versions that is not in the tables above has not been merged.
3. **Alternative prerequisites.** A prerequisite entry means every listed course is required. "This or that" is not expressible yet.
4. **Enforce `mutual_exclusions`** as a Tier 3 consistency rule, with a case that exercises it.
5. **Test cases** `sem_002` to `sem_004` and `con_001`, `con_002` were written by Claude and have not been reviewed by a teammate.
