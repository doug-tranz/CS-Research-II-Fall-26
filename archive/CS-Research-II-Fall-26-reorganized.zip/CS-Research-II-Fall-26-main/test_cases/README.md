# test_cases/

Sorted by the task 1.4 test case types (Ben P):

- **syntactic/** can be checked from the model's output alone, without knowing what the student wanted
- **semantic/** needs the student's request and record to know whether the answer is right

| Folder | Criteria | Cases now |
|---|---|---|
| `syntactic/format` | S1–S5: valid JSON, no code fence or prose, one object, not empty or truncated | none yet |
| `syntactic/message_structure` | S6–S11: id/type/body, exact type URI, student_id, sections list of strings, no extra fields | none yet |
| `syntactic/values` | S12–S17: hallucinated section or student_id, invented course, duplicate, full section, time conflict | none yet |
| `semantic/temporal` | T1–T9 | `busy_block` (T4), 42 |
| `semantic/days` | D1–D3 | `days` (D1), 42 |
| `semantic/capacity` | C1–C4 | `full_fallback` (C1, C4), 42 |
| `semantic/identity` | I1–I5 | none yet |
| `semantic/request_constraints` | K1–K8 | `modality` (K1), 42 |
| `semantic/student_record` | R1–R12 | `in_progress` (R5), `transfer` (R6, R9), `nested_groups` (R9), `credit_limit` (R10), `grade_threshold` (R7), `withdrawal` (R2): 232 |
| `semantic/completeness` | O1–O3 | none yet |
| `todo` | cases that don't fit a category yet | none |

`categories.json` maps each case's `ground_truth.case_type` to its folder (and records which
criteria each type exercises). A case whose type isn't listed goes in `todo/` until someone gives
it a category. Empty folders hold a `.gitkeep` so git keeps them.

Each generator writes its own file inside each folder, so generators never overwrite each
other's cases:

- `generate_pairs.py` → `<folder>/paired_cases.json`
- a new generator (Tyler's, for example) → `<folder>/<its own name>.json`, written with
  `paths.write_cases(cases, "<its own name>.json")` from `src/paths.py`, after adding its case
  types to `categories.json`

Every file is a JSON array of cases. The runner reads every `.json` file under this folder by
default; to run fewer, point `--test-file` at a folder or a file:

```bash
python src/run_semantic_eval.py --check                                          # everything
python src/run_semantic_eval.py --check --test-file test_cases/semantic/student_record
```

To move a case type to another folder, edit `categories.json` and run
`python src/generate_pairs.py --annotate`, which rewrites the pair files into their new folders.
