"""Where everything lives, in one place: the repo's folders, and how test cases are stored.

Every script finds its files through these paths (anchored on the repo root, not the current
directory), so they run the same from anywhere:

    python src/run_semantic_eval.py --check          # from the repo root
    cd src && python run_semantic_eval.py --check    # also works

Test cases live in test_cases/<kind>/<category>/ (task 1.4: syntactic or semantic, then the group). Which category
a case goes in comes from test_cases/categories.json, keyed by the case's ground_truth.case_type;
a case whose type is not listed goes in test_cases/todo/. A category is a path under test_cases/,
e.g. "semantic/student_record". Each generator writes its own file in
each folder (generate_pairs.py writes paired_cases.json), so generators never overwrite each
other's cases. --test-file takes the whole folder (the default), one category folder, or one file.
"""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
SCHEMAS = ROOT / "schemas"
DATA = ROOT / "data"
TEST_CASES = ROOT / "test_cases"
RESULTS = ROOT / "results"

CATEGORY_MAP = TEST_CASES / "categories.json"
TODO = "todo"


def case_files(path=TEST_CASES) -> list:
    """The case files a --test-file names: the file itself, or every .json under a folder
    (categories.json excluded), in a fixed order."""
    path = Path(path)
    if path.is_dir():
        return sorted(p for p in path.rglob("*.json") if p.resolve() != CATEGORY_MAP.resolve())
    return [path]


def read_cases(path=TEST_CASES) -> list:
    """Every case in a file or folder, as one list."""
    cases = []
    for file in case_files(path):
        cases.extend(json.loads(file.read_text(encoding="utf-8")))
    return cases


def cases_hash(path=TEST_CASES) -> str:
    """The first 16 hex digits of a sha256 over the case files. For a single file this is the
    file's own sha256, as before the reorganization."""
    files = case_files(path)
    if len(files) == 1 and not Path(path).is_dir():
        return hashlib.sha256(files[0].read_bytes()).hexdigest()[:16]
    h = hashlib.sha256()
    for file in files:
        h.update(str(file.relative_to(Path(path))).replace("\\", "/").encode("utf-8") + b"\0")
        h.update(file.read_bytes())
    return h.hexdigest()[:16]


def categories() -> dict:
    """case_type -> category folder, from test_cases/categories.json."""
    if not CATEGORY_MAP.exists():
        return {}
    return json.loads(CATEGORY_MAP.read_text(encoding="utf-8"))["case_type_to_category"]


def category_of(case: dict, mapping: dict | None = None) -> str:
    """The folder a case belongs in; todo when its case_type has no category."""
    mapping = categories() if mapping is None else mapping
    return mapping.get((case.get("ground_truth") or {}).get("case_type"), TODO)


def _dump(cases: list) -> bytes:
    """The case-file format generate_pairs.py has always written (indented, CRLF)."""
    return (json.dumps(cases, indent=2, ensure_ascii=False).replace("\n", "\r\n") + "\r\n").encode("utf-8")


def write_cases(cases: list, file_name: str, root=TEST_CASES) -> list:
    """Writes cases into root/<category>/<file_name>, keeping their order within each category.
    Removes this file name from folders that no longer get any cases (so a changed mapping
    leaves no stale copies), and never touches other generators' files. Returns the files written."""
    root = Path(root)
    mapping = categories()
    by_folder = {}
    for case in cases:
        by_folder.setdefault(category_of(case, mapping), []).append(case)
    written = []
    for folder, group in by_folder.items():
        file = root / folder / file_name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(_dump(group))
        written.append(file)
    for stale in root.rglob(file_name):
        if stale.parent.relative_to(root).as_posix() not in by_folder:
            stale.unlink()
    return written


def rel(path) -> str:
    """A path as written in results files and messages: relative to the repo root when inside it."""
    p = Path(path).resolve()
    try:
        return p.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)
