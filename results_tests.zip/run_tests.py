"""Test harness: checks 'Program Guides by Major' PDF against the transcript JSON."""
import json, re, sys
from collections import defaultdict

DATA = json.load(open("data.json"))
RAW = open("raw.txt").read()
LAYOUT = open("guides.txt").read()

GP = {"A": 4.0, "A-": 3.7, "B+": 3.3, "B": 3.0, "B-": 2.7, "C+": 2.3, "C": 2.0,
      "C-": 1.7, "D+": 1.3, "D": 1.0, "D-": 0.7, "F": 0.0}
TERM_ORDER = {"Spring": 0, "Summer": 1, "Fall": 2}
def term_key(t):
    s, y = t.split()
    return int(y) * 3 + TERM_ORDER[s]

results = []  # (test, student, status, detail)
def record(test, sid, ok, detail=""):
    results.append((test, sid, "PASS" if ok else "FAIL", detail))

# ---------- parse PDF ----------
# per-student header lines
hdr = {}
for m in re.finditer(r"(\d+) of 120 credits earned; (\d+) in progress this fall[^;]*; (\d+) still needed after Fall 2026(.*?)Projected finish: (\w+ \d{4})", RAW, re.S):
    pass
# locate each student section by the "Sxxx ·" heading (some headings are split across lines, so index by header line order)
sections = {}
heads = list(re.finditer(r"(\d+) of 120 credits earned; (\d+) in progress this fall", RAW))
# map header order to student IDs using the "All students" table order per major (guides appear in major order)
guide_order = ["S200","S207","S212","S220","S202","S205","S213","S222","S203","S208","S211","S218",
               "S204","S210","S217","S223","S201","S209","S216","S221","S206","S214","S215","S219"]
assert len(heads) == 24, len(heads)
for i, m in enumerate(heads):
    end = heads[i+1].start() if i + 1 < 24 else len(RAW)
    sections[guide_order[i]] = RAW[m.start():end]

pdf = {}
for sid, txt in sections.items():
    flat = " ".join(txt.split())
    m = re.match(r"(\d+) of 120 credits earned; (\d+) in progress this fall.*?; (\d+) still needed after Fall 2026(.*?)Projected finish: (\w+ \d{4})", flat)
    earned, inprog, needed, split, finish = int(m[1]), int(m[2]), int(m[3]), m[4], m[5]
    sp = re.search(r"\((\d+) in specific requirements, (\d+) in free electives\)", split)
    spec, free = (int(sp[1]), int(sp[2])) if sp else (needed, 0)
    terms = [(t, int(c)) for t, c in re.findall(r"((?:Spring|Summer|Fall) 20\d\d) \((\d+) cr\):", flat)]
    notes_part = flat.split("Advisor notes:")[1] if "Advisor notes:" in flat else ""
    notes_part = notes_part.split("Source ")[0]
    pdf[sid] = dict(earned=earned, inprog=inprog, needed=needed, spec=spec, free=free,
                    finish=finish, terms=terms, flat=flat, notes=notes_part)

# "All students" overview table
overview = {}
for m in re.finditer(r"^ *(S2\d\d) +([A-Za-z ]+?) +(Fall 20\d\d) +(Senior|Junior|Sophomore|First-year) +(\d+) +(\d+) +(\w+ 20\d\d)", LAYOUT, re.M):
    overview[m[1]] = dict(standing=m[4], earned=int(m[5]), needed=int(m[6]), finish=m[7])
# per-major "Students at a glance"
glance = {}
for m in re.finditer(r"^ *(S2\d\d) +Fall 20\d\d +.*?(Senior|Junior|Sophomore|First-year) +(\d+) / 120 +(\d+) +(\d+) +([\d.]+|—) +(\w+ 20\d\d)(?: +(\d+))?", LAYOUT, re.M):
    glance[m[1]] = dict(standing=m[2], earned=int(m[3]), inprog=int(m[4]), needed=int(m[5]),
                        gpa=m[6], finish=m[7], notes=int(m[8]) if m[8] else None)
# Art Ed claimed art/prof-ed GPA
artgpa = {sid: float(g) for sid, g in re.findall(r"(S2\d\d).*?courses is about ([\d.]+)", " ".join(RAW.split()))}
artgpa = {}
for sid in ("S201", "S209", "S216"):
    g = re.search(r"courses is about ([\d.]+)", pdf[sid]["flat"])
    artgpa[sid] = float(g[1])

# ---------- recompute from transcripts ----------
calc = {}
for rec in DATA:
    s, tr = rec["student"], rec["transcript"]
    sid = s["student_id"]
    comp = tr["completed_courses"]
    by_course = defaultdict(list)
    for c in comp:
        by_course[c["course_id"]].append(c)
    for v in by_course.values():
        v.sort(key=lambda c: term_key(c["term"]))
    passed = {cid for cid, v in by_course.items() if any(c["grade"] not in ("W", "F") for c in v)}
    earned = sum(max(c["credit_hours"] for c in v if c["grade"] not in ("W", "F")) for cid, v in by_course.items() if cid in passed)
    earned += sum(t["credit_hours"] for t in tr["transfer_courses"])
    # GPA: all attempts vs latest-attempt-replaces
    def gpa(rows):
        q = [(GP[c["grade"]], c["credit_hours"]) for c in rows if c["grade"] in GP]
        return round(sum(a*b for a, b in q) / sum(b for _, b in q), 2) if q else None
    gpa_all = gpa(comp)
    gpa_latest = gpa([[c for c in v if c["grade"] in GP][-1] for v in by_course.values() if any(c["grade"] in GP for c in v)])
    inprog = sum(c["credit_hours"] for c in tr["courses_in_progress"])
    ip_ids = {c["course_id"] for c in tr["courses_in_progress"]}
    had_w = any(c["grade"] == "W" for c in comp)
    had_f = any(c["grade"] == "F" for c in comp)
    unresolved = [v[-1]["title"] for cid, v in by_course.items() if cid not in passed]  # only W/F attempts
    unresolved_not_retaking = [by_course[cid][-1]["title"] for cid in by_course if cid not in passed and cid not in ip_ids]
    retook_passed = any(len(v) > 1 and v[0]["grade"] in ("W", "F") and cid in passed for cid, v in by_course.items())
    attempts3 = [v[0]["title"] for cid, v in by_course.items() if len(v) + (cid in ip_ids) >= 3]
    calc[sid] = dict(major=s["major"], earned=earned, gpa_all=gpa_all, gpa_latest=gpa_latest, inprog=inprog,
                     had_w=had_w, had_f=had_f, unresolved=unresolved, unresolved_nr=unresolved_not_retaking,
                     retook_passed=retook_passed, transfer=bool(tr["transfer_courses"]),
                     first=not comp, tags=set(rec["tags"]), summary=rec["summary"], rec=rec,
                     attempts3=attempts3, by_course=by_course, ip=tr["courses_in_progress"])

def standing(cr):  # thresholds the PDF appears to use
    return "First-year" if cr < 30 else "Sophomore" if cr < 60 else "Junior" if cr < 90 else "Senior"
def standing_rowan(cr):  # common Rowan cut-offs (0-23 / 24-55 / 56-89 / 90+)
    return "First-year" if cr < 24 else "Sophomore" if cr < 56 else "Junior" if cr < 90 else "Senior"

for sid in sorted(calc):
    c, p, o, g = calc[sid], pdf[sid], overview.get(sid), glance.get(sid)
    # T1 data integrity: summary credits/GPA vs recomputed
    record("T01 JSON earned_credits matches recomputed", sid, c["earned"] == c["summary"]["earned_credits"],
           f"json={c['summary']['earned_credits']} recomputed={c['earned']}")
    sg = c["summary"]["gpa"]
    record("T02 JSON GPA matches recomputed (repeat replaces earlier grade)", sid,
           sg == c["gpa_latest"],
           f"json={sg} all-attempts={c['gpa_all']} latest-replaces={c['gpa_latest']}")
    # T3-6 PDF vs data
    record("T03 PDF earned credits = transcript", sid, p["earned"] == c["earned"], f"pdf={p['earned']} data={c['earned']}")
    record("T04 PDF in-progress credits = transcript", sid, p["inprog"] == c["inprog"], f"pdf={p['inprog']} data={c['inprog']}")
    record("T05 PDF GPA (glance table) = transcript", sid,
           (g["gpa"] == "—" and sg is None) or (sg is not None and abs(float(g["gpa"]) - sg) < 0.005), f"pdf={g['gpa']} json={sg}")
    # T6 internal consistency across the 3 places a number appears
    same = (o["earned"], o["needed"], o["finish"]) == (g["earned"], g["needed"], g["finish"]) == (p["earned"], p["needed"], p["finish"])
    record("T06 Overview / glance / guide header agree", sid, same and o["standing"] == g["standing"],
           f"overview={o} glance=({g['earned']},{g['needed']},{g['finish']}) header=({p['earned']},{p['needed']},{p['finish']})")
    # T7 specific + free = needed
    record("T07 specific + free = still needed", sid, p["spec"] + p["free"] == p["needed"], f"{p['spec']}+{p['free']} vs {p['needed']}")
    # T8 plan credits sum to still needed
    tot = sum(cr for _, cr in p["terms"])
    record("T08 suggested-path credits sum = still needed", sid, tot == p["needed"], f"path={tot} needed={p['needed']}")
    # T9 last path term = projected finish
    last = p["terms"][-1][0] if p["terms"] else None
    record("T09 last path term = projected finish", sid, last == p["finish"], f"last={last} finish={p['finish']}")
    # T10 path starts Spring 2027 and terms are consecutive/ordered
    keys = [term_key(t) for t, _ in p["terms"]]
    record("T10 path starts Spring 2027, terms in order", sid, p["terms"][0][0] == "Spring 2027" and keys == sorted(keys) and len(set(keys)) == len(keys),
           ", ".join(t for t, _ in p["terms"]))
    # T11 no term over 18 cr (normal full-time cap)
    over = [f"{t} ({cr})" for t, cr in p["terms"] if cr > 18]
    record("T11 no planned term above 18 cr", sid, not over, "; ".join(over))
    # T12 total credits at graduation >= 120
    total = c["earned"] + c["inprog"] + p["needed"]
    record("T12 earned + in progress + still needed >= 120", sid, total >= 120, f"total={total}")
    # T13 standing label consistent with credits
    record("T13 standing matches 30/60/90 cut-offs", sid, g["standing"] == standing(c["earned"]),
           f"pdf={g['standing']} credits={c['earned']} (Rowan 24/56/90 rule would say {standing_rowan(c['earned'])})")
    # T14 tags in JSON consistent with transcript
    exp = set()
    if c["had_w"]: exp.add("has_withdrawal")
    if c["had_f"]: exp.add("has_failure")
    if c["retook_passed"]: exp.add("retook_and_passed")
    if c["unresolved"]: exp.add("unresolved_w_or_f")
    if c["transfer"]: exp.add("has_transfer")
    if c["first"]: exp.add("first_semester")
    if sg is not None and sg < 2: exp.add("gpa_below_2")
    if c["earned"] >= 90: exp.add("senior_standing")
    record("T14 JSON tags match transcript", sid, exp == c["tags"],
           f"missing={sorted(exp - c['tags'])} extra={sorted(c['tags'] - exp)}")
    # T15 every unresolved W/F is mentioned (as 'not yet made up' or 'retaking now')
    miss = [t for t in c["unresolved"] if t not in p["notes"]]
    record("T15 each unresolved W/F appears in advisor notes", sid, not miss, "missing: " + ", ".join(miss))
    # T16 notes don't call something 'not yet made up' that was made up
    m = re.search(r"W or F not yet made up: (.*?)(?= Retaking| Three| Taken| Transfer| Minor| S2\d\d ·|$)", p["notes"])
    listed = [x.strip(" .") for x in m[1].split(",")] if m else []
    wrong = [x for x in listed if x not in c["unresolved_nr"]]
    record("T16 'W or F not yet made up' list is accurate", sid, not wrong, "wrong: " + ", ".join(wrong))
    # T17 3+ attempts flagged
    miss3 = [t for t in c["attempts3"] if t.lower() not in p["notes"].lower()]
    record("T17 courses with 3+ attempts are flagged", sid, not miss3, "missing: " + ", ".join(miss3))
    # T18 advisor-note count in glance table = bullets in guide
    if g["notes"] is not None:
        n = p["notes"].count("•")
        record("T18 glance 'Advisor notes' count = bullets", sid, n == g["notes"], f"glance={g['notes']} bullets={n}")
    # T19 GPA < 2.0 flagged
    if sg is not None and sg < 2:
        record("T19 GPA below 2.00 flagged in notes", sid, "below Rowan" in p["notes"], f"gpa={sg}")
    # T20 every in-progress course is mentioned somewhere in the student's guide
    ALIAS = {"ART09201": "Community Art Ed: Elementary", "ART09202": "Community Art Ed: Secondary",
             "SECD03330": "Clinical Experience A: Art", "CHEM01100": "Chemistry I",
             "CS04222": "Data Structures and Algorithms", "CS04113": "Intro to Object-Oriented Programming",
             "HES00116": "Safety, First Aid & Athletic Injuries"}
    flat_l = p["flat"].lower()
    # only look in the requirement tables and notes, not the suggested path (which lists future courses)
    body = flat_l.split("suggested path to finish")[0] + " " + p["notes"].lower()
    missing_ip = [ip["title"] for ip in c["ip"]
                  if ALIAS.get(ip["course_id"], ip["title"]).lower()[:28] not in body]
    record("T20 every in-progress course shows up in the guide", sid, not missing_ip, "not shown: " + ", ".join(missing_ip))
    # T21 Exercise Science: 300/400-level major courses taken on Glassboro campus
    if c["major"] == "Exercise Science":
        bad = [f"{x['title']} ({x['campus']})" for v in c["by_course"].values() for x in v
               if re.match(r"(HES|HPW|NUT|ATR)\d{2}[34]\d\d", x["course_id"]) and x["grade"] not in ("W","F") and x["campus"] != "Glassboro"]
        record("T21 ExSci 300/400 major courses at Glassboro", sid, not bad, "; ".join(bad))
    # T22 Art Ed art + prof-ed GPA claim
    if sid in artgpa:
        PRE = ("ART", "ARHS", "SPED", "READ", "SMED", "FNDS", "SECD", "EDUC", "INCL", "ELEM")
        rows = [x for v in c["by_course"].values() for x in v if x["grade"] in GP and (x["course_id"].startswith(PRE) or x["course_id"] == "PSY09209")]
        q = sum(GP[x["grade"]] * x["credit_hours"] for x in rows) / sum(x["credit_hours"] for x in rows)
        latest = [[x for x in v if x["grade"] in GP][-1] for v in c["by_course"].values()
                  if any(x["grade"] in GP for x in v) and (v[0]["course_id"].startswith(PRE) or v[0]["course_id"] == "PSY09209")]
        q2 = sum(GP[x["grade"]] * x["credit_hours"] for x in latest) / sum(x["credit_hours"] for x in latest)
        record("T22 Art Ed art/prof-ed GPA claim (incl. Child & Adolescent Dev) reproducible", sid, abs(q2 - artgpa[sid]) <= 0.02,
               f"pdf≈{artgpa[sid]} recomputed={q2:.2f} (PDF figure matches only if PSY 09209 is left out)")

# ---------- report ----------
fails = [r for r in results if r[2] == "FAIL"]
print(f"{len(results)} checks, {len(results)-len(fails)} pass, {len(fails)} fail\n")
by_test = defaultdict(list)
for r in results: by_test[r[0]].append(r)
for t in sorted(by_test):
    rs = by_test[t]; f = [r for r in rs if r[2] == "FAIL"]
    print(f"{t}: {len(rs)-len(f)}/{len(rs)} pass")
    for r in f: print(f"    FAIL {r[1]}: {r[3]}")
json.dump(results, open("results.json", "w"), indent=1)

# ---------- rule-logic checks (targeted) ----------
logic = []
def lrec(name, sid, ok, detail):
    logic.append((name, sid, "PASS" if ok else "FAIL", detail))
title_grade = {sid: {x["title"]: x["grade"] for v in c["by_course"].values() for x in v if x["grade"] in GP} for sid, c in calc.items()}
# L1: Art Ed requires C- or better in every required course; check Rowan Core literacies used
for sid in ("S201", "S209", "S216"):
    used = re.findall(r"(?:Artistic|Global|Quantitative): ([A-Za-z0-9 &:\-]+?)(?:;|—| Rowan| General)", pdf[sid]["flat"])
    low = [f"{u.strip()} ({title_grade[sid].get(u.strip())})" for u in used if GP.get(title_grade[sid].get(u.strip(), "A"), 4) < 1.7]
    lrec("L1 Art Ed: courses used for requirements meet C- floor", sid, not low, "; ".join(low))
# L2: 'Rowan Seminar' attribute claims must be backed by transcript attributes (no RS tags exist in the data)
has_rs = any("RS" in x.get("attributes", []) for r in DATA for x in r["transcript"]["completed_courses"])
for sid, p in pdf.items():
    m = re.search(r"Rowan Seminar: ([A-Za-z ]+?)(?: —|$| a course)", p["flat"])
    if m:
        lrec("L2 Rowan Seminar credit backed by transcript attribute", sid, has_rs, f"guide credits RS via '{m[1].strip()}', but no course in the data carries an RS attribute")
# L3: a course should not be both 'minor credit' and a major requirement
p = pdf["S206"]["flat"]
lrec("L3 S206 in-progress credit not double-labelled", "S206",
     not ("including 3 minor credits" in p and "Entrepreneurship and Innovation" in p.split("Suggested path")[0]),
     "header calls 3 in-progress credits 'minor credits', but Entrepreneurship and Innovation (ENT 06240) is also shown as an in-progress major foundational course")
# L4: CS restricted-elective treatment consistent across students
s200 = pdf["S200"]["flat"]; s207 = pdf["S207"]["flat"]
lrec("L4 CS: same course classified the same way for every student", "S200/S207",
     False if ("Web Application Development (6 of 12" in s207 or "Web Application Development (6" in s207 or "Web Application Development" in s207.split("CS restricted electives")[1][:200]) and "Web Application Development" in s200.split("free electives:")[-1] else True,
     "S207 counts Web App Dev, Operating Systems, Database Systems as CS restricted electives; S200's notes call the same courses 'not on Rowan's CS requirement list' (they are overflow once S200's 12 cr are filled)")
# L5: CS courses the student took that plausibly satisfy a still-needed requirement (code mismatch only)
EQUIV = {"CS05100": "Operating Systems", "CS03351": "Computer Organization", "CS05000": "Software Engineering I",
         "CS07450": "Design and Analysis of Algorithms", "MATH02100": "Discrete Structures", "CS06000": "Senior Project", "CS06001": "Senior Project"}
for sid in ("S200", "S207", "S212"):
    c = calc[sid]
    taken = {cid for cid, v in c["by_course"].items() if any(x["grade"] not in ("W","F") for x in v)} | {x["course_id"] for x in c["ip"]}
    hits = [f"{cid}→{req}" for cid, req in EQUIV.items() if cid in taken and req in pdf[sid]["flat"].split("Suggested path")[0].split("Still needed")[-1]]
    lrec("L5 CS: no still-needed item already covered by a same-named course", sid, not hits, "; ".join(hits))

print()
for r in logic:
    print(f"{r[0]}: {r[2]} {r[1]}" + (f" — {r[3]}" if r[2] == "FAIL" else ""))
json.dump(results + logic, open("results.json", "w"), indent=1)
